<?php
class FetchData{ 
	var $dbconn ='';
    var $currencyId = '';
    var $broker = '';
	var $sentiment = '';
	var $ValueLessOrGreater = '';
	var $NetVal = '';
	var $Currency = '';
	var $timeframe = '';
	var $startDate = '';
	var $endDate = '';

	var $timeframe1 = '';
	var $timeframe2 = '';
	var $timeframe3 = '';

	var $toTimeframe1 = '';
	var $toTimeframe2 = '';
	var $toTimeframe3 = '';

	var $dataArr = array();
	var $bQueryStr = '';
     
    function __construct($params){ 
    	require("config.php");
        $this->dbconn = $conn; 
        if (count($params) > 0){
	        $this->Broker = $params['Broker'];
			$this->sentiment = $params['sentiment'];
			$this->ValueLessOrGreater = $params['ValueLessOrGreater'];
			$this->NetVal = $params['NetVal'];
			$this->Currency = $params['Currency'];
			$this->timeframe = $params['Timeframe'];
			$this->startDate = date("Y-m-d", strtotime($params['startDate']));
			$this->endDate = date("Y-m-d", strtotime($params['endDate']));

			$this->timeframe1 = $params['Timeframe1'];
			$this->timeframe2 = $params['Timeframe2'];
			$this->timeframe3 = $params['Timeframe3'];

			$this->toTimeframe1 = $params['ToTimeframe1'];
			$this->toTimeframe2 = $params['ToTimeframe2'];
			$this->toTimeframe3 = $params['ToTimeframe3'];

            //$this->searchData();         
        }
        
         
    }


    function searchData($currencyId){

    	$this->dataArr = array(); 

    	$this->currencyId = $currencyId;
		if($this->broker){
			$brokersInfo = $this->dbconn->query("SELECT * FROM website where Id_Website IN (".$this->broker.") ORDER BY Id_Website ASC");
		}else{
			$brokersInfo = $this->dbconn->query("SELECT * FROM website ORDER BY Id_Website ASC");
		}

		$brokerStr = "['$this->timeframe', ";

		foreach($brokersInfo as $row) {
		    $brokerStr .= "'".$row['Website'] ."', ";
		}
		$brokerStr = rtrim($brokerStr, ', ');
		$brokerStr .= "]";


		array_push($this->dataArr, $brokerStr);

		$this->bQueryStr = "";
		$result = '';
		if($this->timeframe == "Month"){
			
			foreach($brokersInfo as $row) {
				$this->bQueryStr .= "(SELECT IFNULL(AVG(a.$this->sentiment),0) FROM arch_sentiment a WHERE a.$this->sentiment $this->ValueLessOrGreater $this->NetVal AND a.Currency_ID=$this->currencyId AND  a.Site_ID = $row[Id_Website] AND MONTH(a.date) = MONTH(s.Date)) $row[Website],";
			}
			$this->bQueryStr = rtrim($this->bQueryStr, ',');
			//$this->searchMonthly();

			// $sql = "SELECT DATE_FORMAT(s.Date, '%b-%y') AS  dataTitle,
			// 	$this->bQueryStr
			// 	FROM Arch_sentiment s 
			// 	WHERE s.$this->sentiment $this->ValueLessOrGreater $this->NetVal 
			// 	AND s.Currency_ID=$this->currencyId 
			// 	AND	s.date BETWEEN '$this->startDate' AND '$this->endDate' 
			// 	AND s.Site_ID IN (1,2,3,7)
			// 	GROUP BY  MONTH(s.Date) 
			// 	ORDER BY MONTH(s.Date)";
			//$this->makeResult($sql);

			$sql = "SELECT DATE_FORMAT(s.Date, '%Y-%m') AS dataMonth, DATE_FORMAT(DATE, '%b-%y') AS  dataTitle, Site_ID, Currency_ID  
				FROM Arch_sentiment s 
				WHERE s.$this->sentiment $this->ValueLessOrGreater $this->NetVal 
				AND s.Currency_ID=$this->currencyId 
				AND	s.date BETWEEN '$this->startDate' AND '$this->endDate' 
				AND s.Site_ID IN (1,2,3,7)
				GROUP BY  MONTH(s.Date) 
				ORDER BY MONTH(s.Date)";
			$this->makeMonthLyResult($sql);

		}else if($this->timeframe == "Week"){
			// Weekly Search

			foreach($brokersInfo as $row) {
				$this->bQueryStr .= "(SELECT IFNULL(AVG(a.$this->sentiment),0) FROM arch_sentiment a WHERE a.$this->sentiment $this->ValueLessOrGreater $this->NetVal AND a.Currency_ID=$this->currencyId AND  a.Site_ID = $row[Id_Website] AND a.date=s.Date) $row[Website],";
			}
			$this->bQueryStr = rtrim($this->bQueryStr, ',');
			//$this->searchDaily();
			$sql = "SELECT CONCAT(YEAR(s.Date), '/', WEEK(s.Date)) AS dataTitle,  DATE(s.Date) AS dataDate,
				$this->bQueryStr
				FROM Arch_sentiment s 
				WHERE s.$this->sentiment $this->ValueLessOrGreater $this->NetVal 
				AND s.Currency_ID=$this->currencyId 
				AND	s.date BETWEEN '$this->startDate' AND '$this->endDate' 
				AND s.Site_ID IN (1,2,3,7)
				GROUP BY  WEEK(s.Date) 
				ORDER BY YEAR(s.Date) ASC, WEEK(s.Date) ASC";
			$this->makeResult($sql);


		}else if($this->timeframe == "Day"){
			foreach($brokersInfo as $row) {
				$this->bQueryStr .= "(SELECT IFNULL(AVG(a.$this->sentiment),0) FROM arch_sentiment a WHERE a.$this->sentiment $this->ValueLessOrGreater $this->NetVal AND a.Currency_ID=$this->currencyId AND  a.Site_ID = $row[Id_Website] AND a.date=s.Date) $row[Website],";
			}
			$this->bQueryStr = rtrim($this->bQueryStr, ',');
				//$this->searchDaily();
				$sql = "SELECT DATE_FORMAT(s.Date, '%d/%m/%y') AS  dataTitle,
				$this->bQueryStr
				FROM Arch_sentiment s 
				WHERE s.$this->sentiment $this->ValueLessOrGreater $this->NetVal 
				AND s.Currency_ID=$this->currencyId 
				AND	s.date BETWEEN '$this->startDate' AND '$this->endDate' 
				AND s.Site_ID IN (1,2,3,7)
				GROUP BY  DATE_FORMAT(s.Date, '%d') 
				ORDER BY DATE_FORMAT(s.Date, '%d')";
			$this->makeResult($sql);


		}else if($this->timeframe == "Hour"){
			foreach($brokersInfo as $row) {
			$this->bQueryStr .= "(SELECT IFNULL(AVG(a.$this->sentiment),0) FROM arch_sentiment a WHERE a.$this->sentiment $this->ValueLessOrGreater $this->NetVal AND a.Currency_ID=$this->currencyId AND  a.Site_ID = $row[Id_Website] AND a.date=s.Date) $row[Website],";
			}
			$this->bQueryStr = rtrim($this->bQueryStr, ',');
			//$this->searchDaily();
			$sql = "SELECT DATE_FORMAT(s.Date, '%d/%m/%y %H:00') AS  dataTitle,
				$this->bQueryStr
				FROM Arch_sentiment s 
				WHERE s.$this->sentiment $this->ValueLessOrGreater $this->NetVal 
				AND s.Currency_ID=$this->currencyId 
				AND	DATE_FORMAT(s.Date, '%Y-%m-%d %H:') BETWEEN '$this->startDate $this->timeframe1:' AND '$this->endDate $this->toTimeframe1:' 
				AND s.Site_ID IN (1,2,3,7)
				GROUP BY  DATE_FORMAT(s.Date, '%Y-%m-%d %H:') 
				ORDER BY DATE_FORMAT(s.Date, '%Y-%m-%d %H:')";
			$this->makeResult($sql);

		}else if($this->timeframe == "Minute"){
			foreach($brokersInfo as $row) {
				$this->bQueryStr .= "(SELECT IFNULL(AVG(a.$this->sentiment),0) FROM arch_sentiment a WHERE a.$this->sentiment $this->ValueLessOrGreater $this->NetVal AND a.Currency_ID=$this->currencyId AND  a.Site_ID = $row[Id_Website] AND a.date=s.Date) $row[Website],";
			}
			$this->bQueryStr = rtrim($this->bQueryStr, ',');
			//$this->searchDaily();
			$sql = "SELECT DATE_FORMAT(s.Date, '%Y-%m-%d %H:%i') AS  dataTitle,
				$this->bQueryStr
				FROM Arch_sentiment s 
				WHERE s.$this->sentiment $this->ValueLessOrGreater $this->NetVal 
				AND s.Currency_ID=$this->currencyId 
				AND	DATE_FORMAT(s.Date, '%Y-%m-%d %H:%i:') BETWEEN '$this->startDate $this->timeframe1:' AND '$this->endDate $this->toTimeframe1:' 
				AND s.Site_ID IN (1,2,3,7)
				GROUP BY  DATE_FORMAT(s.Date, '%Y-%m-%d %H:%i:') 
				ORDER BY DATE_FORMAT(s.Date, '%Y-%m-%d %H:%i:')";
			$this->makeResult($sql);

		}else{

			foreach($brokersInfo as $row) {
				$this->bQueryStr .= "(SELECT IFNULL(AVG(a.$this->sentiment),0) FROM arch_sentiment a WHERE a.$this->sentiment $this->ValueLessOrGreater $this->NetVal AND a.Currency_ID=$this->currencyId AND  a.Site_ID = $row[Id_Website] AND a.date=s.Date) $row[Website],";
			}
			$this->bQueryStr = rtrim($this->bQueryStr, ',');
			//$this->searchDaily();
			$sql = "SELECT DATE_FORMAT(s.Date, '%H:%i:%s') AS  dataTitle,
				$this->bQueryStr
				FROM Arch_sentiment s 
				WHERE s.$this->sentiment $this->ValueLessOrGreater $this->NetVal 
				AND s.Currency_ID=$this->currencyId 
				AND	DATE_FORMAT(s.Date, '%Y-%m-%d %H:%i:%s') BETWEEN '$this->startDate $this->timeframe1:' AND '$this->endDate $this->toTimeframe1:' 
				AND s.Site_ID IN (1,2,3,7)
				GROUP BY  DATE_FORMAT(s.Date, '%Y-%m-%d %H:%i:%s') 
				ORDER BY DATE_FORMAT(s.Date, '%Y-%m-%d %H:%i:%s')";
			$this->makeResult($sql);

		}

		return json_encode($this->dataArr);


    } 


    function makeResult($sql){
		$query = $this->dbconn->query($sql);

		$dataStr = "";
		foreach($query as $row) {
			$dataStr = "['$row[dataTitle]', $row[Oanda], $row[dailyfx], $row[MyFxbook], $row[IG]]";
			array_push($this->dataArr, $dataStr);
		}
		return true;
    }


    function makeMonthLyResult($sql){
    	$query = $this->dbconn->query($sql);
		foreach($query as $row) {
			$dataStr = "";
			$sql2 = "SELECT w.Id_Website, 
					(SELECT IFNULL(ROUND(AVG($this->sentiment)),0)  
					FROM `arch_sentiment` 
					WHERE NetLong < 100 
					AND Currency_ID=1 
					AND DATE_FORMAT(DATE, '%Y-%m') = '".$row['dataMonth']."' 
					AND Site_ID = w.Id_Website) AS avgval 
				FROM website w
				WHERE w.Id_Website IN (1,2,3,7) 
				GROUP BY w.Id_Website
				ORDER BY w.Id_Website";
			$query2 = $this->dbconn->query($sql2);

			$dataStr .="['$row[dataTitle]',";

			foreach($query2 as $row2){
				$dataStr .= $row2['avgval'].",";
			}
			$dataStr = rtrim($dataStr, ",");
			$dataStr .="]";
			array_push($this->dataArr, $dataStr);
		}
		return true;



    }

}



?>